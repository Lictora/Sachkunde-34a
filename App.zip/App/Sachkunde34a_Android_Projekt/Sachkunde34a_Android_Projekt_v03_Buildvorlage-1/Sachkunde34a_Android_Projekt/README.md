# Sachkunde34a Android-Lern-App – Entwicklungsstand 0.2

## Inhalt
Native Android-Java-App mit Offline-Fragen und HTTPS-Updates. 164 IHK- und 108 WSK-Fragen aus dem Homepage-Export vom 31.10.2026 importiert. 12 WSK-Fragen mit 3 korrekten Antworten separat zur fachlichen Prüfung abgelegt. **Alle importierten Fragen sind fachlich/rechtlich noch nicht abschließend geprüft.**

## Android-Build
Android Studio öffnen → Projektordner wählen → Gradle synchronisieren → Build APK(s). SDK 35 und JDK 17 nötig. Kein Gradle-Wrapper beigelegt, keine APK gebaut oder auf Android getestet.

## Update-Datei für Telekom-Webspace
Die Datei `webspace/app/questions.json` ist ein **Entwurf zur fachlichen Prüfung, NICHT ungeprüft live veröffentlichen**. Nach Prüfung unter `https://www.sachkunde34a.info/app/questions.json` veröffentlichen. Beim App-Start und manuell wird das JSON über HTTPS abgerufen; offline bleibt der letzte gültige Stand verfügbar. Keine periodischen Hintergrundupdates, keine digitale Signatur. Der Update-Endpunkt ist noch nicht eingerichtet.

## Aktuelle Einschränkungen
Die Simulation zieht zufällig 82 IHK-Fragen und läuft 120 Minuten. Aktuell gibt es nur eine einfache Richtig/Falsch-Auswertung, **keine korrekte IHK-Teilpunktewertung** und keine gesicherte Verteilung nach Prüfungsgebieten. Nicht als amtliche IHK-Prüfung darstellen. Für WSK sind 12 Aufgaben mit drei richtigen Antworten zurückgestellt; sie dürfen nicht willkürlich geändert werden. Für eine Veröffentlichung fehlen u. a. Rechtsprüfung, Datenschutzprüfung, zuverlässige Update-Signatur, App-Tests und signierte APK.

## Version 0.3: Test-APK bauen (ohne eigenen PC möglich)
Diese ZIP ist **keine APK**. Der Container hatte weder Android-SDK noch Gradle; ein lokaler APK-Build und ein Gerätetest waren nicht möglich.

Im Projekt liegt `.github/workflows/android-apk.yml`. Zum Erstellen einer **Debug-Test-APK**:
1. Auf github.com ein privates Repository erstellen und den **Inhalt des Projektordners** hochladen (einschließlich des versteckten `.github`-Ordners).
2. GitHub → Actions → Android Test-APK → Run workflow (alternativ: Push auf `main`).
3. Nach erfolgreichem Lauf unter **Artifacts** `Sachkunde34a-Test-APK` herunterladen, ZIP entpacken und `app-debug.apk` auf dem Xiaomi öffnen.
4. Android kann um die Freigabe für Installationen aus dieser Quelle bitten. Nur die selbst erstellte APK verwenden.

Die Debug-APK ist nur für private Tests, nicht für den Play Store. Sie ist weder signiert für eine Veröffentlichung noch auf einem Gerät getestet. Fragenupdates funktionieren erst, wenn eine geprüfte JSON-Datei unter der im Code angegebenen HTTPS-Adresse veröffentlicht wurde. Das ist noch nicht geschehen.
